QT -= gui
TARGET = StringLib
TEMPLATE = lib
CONFIG += shared c++17
DEFINES += STRINGLIB_LIBRARY

HEADERS += \
    mystring.h

SOURCES += \
    mystring.cpp

# ── Fix: Qt 6.11.0 + Apple Silicon (arm64) — missing <arm_acle.h> ──────────
macx {
    QMAKE_CXXFLAGS += -Wno-implicit-function-declaration
}

unix {
    target.path = /usr/lib
    INSTALLS += target
}
